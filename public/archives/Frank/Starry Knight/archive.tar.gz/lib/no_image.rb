class NoImage
  def draw(*args) ; end
  def draw_rot(*args) ; end
  def width ; 1 ; end
  def height ; 1 ; end
end